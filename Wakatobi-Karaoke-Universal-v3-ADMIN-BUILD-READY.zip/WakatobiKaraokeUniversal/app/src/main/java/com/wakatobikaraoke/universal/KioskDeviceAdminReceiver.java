package com.wakatobikaraoke.universal;

import android.app.admin.DeviceAdminReceiver;

public class KioskDeviceAdminReceiver extends DeviceAdminReceiver {
}
