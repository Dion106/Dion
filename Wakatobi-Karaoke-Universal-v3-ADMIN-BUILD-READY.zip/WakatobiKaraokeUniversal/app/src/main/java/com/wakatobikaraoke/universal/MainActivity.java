package com.wakatobikaraoke.universal;

import android.annotation.SuppressLint;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.GridLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS = "wakatobi_universal";
    private static final String KEY_ROOM = "room_id";
    private static final String BASE_URL = "https://biztech.my.id/touchscreen/?room=";
    private static final int ROOM_COUNT = 20;

    private WebView webView;
    private LinearLayout setupPanel;
    private GridLayout roomGrid;
    private TextView selectedRoom;
    private TextView offlineView;
    private SharedPreferences prefs;
    private String pendingRoom = "";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wakeLock;
    private View adminHotspot;
    private int adminTapCount = 0;
    private long lastAdminTap = 0L;
    private static final String ADMIN_PIN = "2580";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        webView = findViewById(R.id.webView);
        setupPanel = findViewById(R.id.setupPanel);
        roomGrid = findViewById(R.id.roomGrid);
        selectedRoom = findViewById(R.id.selectedRoom);
        offlineView = findViewById(R.id.offlineView);
        adminHotspot = findViewById(R.id.adminHotspot);
        setupAdminHotspot();
        Button save = findViewById(R.id.saveRoomButton);

        save.setOnClickListener(v -> saveSelectedRoom());

        buildRoomGrid();
        acquireWakeLock();

        String room = prefs.getString(KEY_ROOM, "");
        if (room.isEmpty()) {
            showSetup();
        } else {
            startRoom(room);
        }
    }

    /**
     * Hidden admin entry: tap the top-left corner 5 times within 2 seconds.
     * This keeps the customer UI clean while giving the operator a reliable exit path.
     */
    private void setupAdminHotspot() {
        if (adminHotspot == null) return;
        adminHotspot.setOnClickListener(v -> {
            long now = System.currentTimeMillis();
            if (now - lastAdminTap > 2000L) {
                adminTapCount = 0;
            }
            lastAdminTap = now;
            adminTapCount++;
            if (adminTapCount >= 5) {
                adminTapCount = 0;
                showAdministratorDialog();
            }
        });
    }

    private void showAdministratorDialog() {
        final EditText pinInput = new EditText(this);
        pinInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pinInput.setSingleLine(true);
        pinInput.setHint("PIN");
        pinInput.setGravity(Gravity.CENTER);
        pinInput.setTextSize(22);

        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setPadding(40, 0, 40, 0);
        wrapper.addView(pinInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 60));

        final android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                .setTitle("ADMINISTRATOR")
                .setMessage("Masukkan PIN")
                .setView(wrapper)
                .setPositiveButton("KEMBALI KE ANDROID", null)
                .setNegativeButton("BATAL", (d, w) -> d.dismiss())
                .create();

        dialog.setOnShowListener(d -> {
            Button exitButton = dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE);
            exitButton.setOnClickListener(v -> {
                String entered = pinInput.getText().toString().trim();
                if (ADMIN_PIN.equals(entered)) {
                    dialog.dismiss();
                    exitKaraokeToAndroid();
                } else {
                    pinInput.setText("");
                    pinInput.requestFocus();
                    Toast.makeText(this, "PIN salah", Toast.LENGTH_SHORT).show();
                }
            });
            pinInput.requestFocus();
            dialog.getWindow().setSoftInputMode(
                    WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        });

        dialog.show();
    }

    private void exitKaraokeToAndroid() {
        try {
            DevicePolicyManager dpm =
                    (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName admin =
                    new ComponentName(this, KioskDeviceAdminReceiver.class);

            if (dpm.isLockTaskPermitted(getPackageName())) {
                try {
                    stopLockTask();
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        }

        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(home);
        finishAndRemoveTask();
    }

    private void buildRoomGrid() {
        for (int i = 1; i <= ROOM_COUNT; i++) {
            final String room = String.format(Locale.US, "room-%02d", i);
            Button b = new Button(this);
            b.setText("ROOM " + String.format(Locale.US, "%02d", i));
            b.setTextSize(14);
            b.setAllCaps(false);
            b.setOnClickListener(v -> {
                pendingRoom = room;
                selectedRoom.setText("Dipilih: " + room.toUpperCase(Locale.US));
                findViewById(R.id.saveRoomButton).setEnabled(true);
            });
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0;
            lp.height = 62;
            lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            lp.setMargins(5, 5, 5, 5);
            roomGrid.addView(b, lp);
        }
    }

    private void showSetup() {
        setupPanel.setVisibility(View.VISIBLE);
        webView.setVisibility(View.GONE);
        hideSystemUi();
    }

    private void saveSelectedRoom() {
        if (pendingRoom.isEmpty()) {
            Toast.makeText(this, "Pilih ROOM 01–20", Toast.LENGTH_SHORT).show();
            return;
        }
        prefs.edit().putString(KEY_ROOM, pendingRoom).apply();
        startRoom(pendingRoom);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void startRoom(String room) {
        setupPanel.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);
        hideSystemUi();
        enterKioskIfAvailable();

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setTextZoom(100);

        if (WebViewFeature.isFeatureSupported(WebViewFeature.SAFE_BROWSING_ENABLE)) {
            WebSettingsCompat.setSafeBrowsingEnabled(s, true);
        }

        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                if (host == null) return true;
                // Keep the WordPress system inside the APK.
                if (host.equals("biztech.my.id") || host.endsWith(".biztech.my.id")) {
                    return false;
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                offlineView.setVisibility(View.GONE);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest req,
                                        WebResourceError error) {
                if (req.isForMainFrame()) {
                    offlineView.setVisibility(View.VISIBLE);
                    scheduleReload();
                }
            }
        });

        loadRoom(room);
    }

    private void loadRoom(String room) {
        webView.loadUrl(BASE_URL + normalizeRoom(room));
    }

    private String normalizeRoom(String raw) {
        String r = raw == null ? "" : raw.trim().toLowerCase(Locale.US);
        r = r.replace(" ", "-");
        if (!r.startsWith("room-") && r.matches("\\d+")) {
            r = "room-" + String.format(Locale.US, "%02d", Integer.parseInt(r));
        }
        return r;
    }

    private void scheduleReload() {
        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(() -> {
            if (isNetworkAvailable()) {
                loadRoom(prefs.getString(KEY_ROOM, "room-01"));
            } else {
                scheduleReload();
            }
        }, 5000);
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        Network n = cm.getActiveNetwork();
        return n != null;
    }

    private void enterKioskIfAvailable() {
        try {
            DevicePolicyManager dpm =
                    (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName admin =
                    new ComponentName(this, KioskDeviceAdminReceiver.class);
            if (dpm.isDeviceOwnerApp(getPackageName())) {
                dpm.setLockTaskPackages(admin, new String[]{getPackageName()});
                startLockTask();
            } else {
                // On non-provisioned devices, immersive mode still hides system UI,
                // but Android may allow exiting the app depending on manufacturer.
                startLockTask();
            }
        } catch (Exception ignored) {
        }
    }

    private void acquireWakeLock() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "WakatobiKaraoke::UniversalRoom");
        wakeLock.acquire(12 * 60 * 60 * 1000L);
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    public void onBackPressed() {
        // Customer cannot exit the karaoke app with Android Back.
    }

    @Override
    protected void onDestroy() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }
}
