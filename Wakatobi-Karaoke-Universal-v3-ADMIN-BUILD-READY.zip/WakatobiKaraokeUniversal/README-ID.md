# Wakatobi Karaoke Universal v2.0

## Tujuan
Satu APK untuk ROOM 01–ROOM 20. Pada instalasi pertama:
1. APK terbuka.
2. Tampil pilihan ROOM 01–ROOM 20.
3. Operator/teknisi memilih room.
4. Tekan SIMPAN ROOM & MULAI.
5. ROOM ID disimpan di perangkat.
6. Setelah restart, APK langsung membuka room yang tersimpan.
7. Tombol Back Android tidak melakukan apa-apa.
8. WebView fullscreen dan layar dijaga tetap menyala.
9. Jika koneksi putus, WebView mencoba reconnect.

## URL WordPress
https://biztech.my.id/touchscreen/?room=room-01

## Kompatibilitas
Target source: Android API 23+ (Android 6.0+), dengan Android System WebView/Chromium yang berfungsi. Tidak ada APK yang dapat dijamin 100% untuk setiap firmware Android; beberapa Android TV Box/projector generik dapat menonaktifkan atau membatasi WebView, auto-start, atau kiosk mode.

Jetpack WebKit dipakai sebagai compatibility layer untuk membantu perbedaan versi WebView.

## Mode kiosk yang benar
Untuk perangkat komersial dedicated, jadikan aplikasi sebagai Device Owner setelah factory reset:
adb shell dpm set-device-owner com.wakatobikaraoke.universal/.KioskDeviceAdminReceiver

Perintah ini hanya untuk teknisi saat provisioning dan dapat gagal jika perangkat sudah memiliki akun/profil yang menghalangi provisioning.

## Auto-start
BootReceiver disiapkan. Namun Android/manufacturer tertentu membatasi Activity start-from-boot. Untuk perangkat yang benar-benar dedicated, gunakan provisioning kiosk/device-owner atau pengaturan auto-start bawaan vendor.

## Catatan WebView
WebView bukan browser penuh: tidak ada address bar. JavaScript, DOM storage, QR code, dan interaksi WordPress dapat digunakan selama halaman web kompatibel dengan WebView.

## Keamanan navigasi
Link yang keluar dari biztech.my.id diblokir agar pelanggan tidak keluar dari sistem karaoke.

## Pengembangan berikutnya yang disarankan
- Halaman teknisi tersembunyi + PIN untuk mengganti ROOM.
- Health check URL/API.
- Status WebView version pada halaman teknisi.
- Auto-relaunch jika Activity crash.
- Remote configuration dari WordPress untuk mengubah URL/fitur tanpa build APK.


## Keluar ke Android / Admin
Untuk menjaga perangkat tetap mudah dipulihkan, aplikasi memiliki menu Administrator tersembunyi.
Ketuk sudut kiri atas 5 kali dalam waktu 2 detik. Masukkan PIN Administrator.

- PIN default: `2580`
- Tombol **KEMBALI KE ANDROID** menghentikan Lock Task bila tersedia lalu membuka Home Android.
- Tombol **BATAL** menutup dialog.
- Untuk produksi, ubah PIN default di `MainActivity.java` sebelum distribusi.
- Jangan mengaktifkan Device Owner/Lock Task penuh sebelum jalur keluar admin diuji pada perangkat target.
